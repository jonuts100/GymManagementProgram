package main;
import java.util.*;
public class Main {
	Scanner scan = new Scanner(System.in);
	InputHandler input = new InputHandler();
	public Main() {
		
		Manager<GymProgram> management = new LocationManagement();
		
		String n;
		
		while(true) {
			System.out.println("===System Initialization===");
			if(management.getList().isEmpty()) {
				System.out.println("System does not have any location registered !\n");
				n = input.getStringInput("Please register the gym's location : ");
				
				management.add(new GymProgram(n));
				
				System.out.println("Great , the location " + n + " has been added !");
				System.out.println();
			}
			else {
				int[] idx= {1};
				System.out.println("Choose a location to manage:");
				
				management.getList().stream().forEach(location ->{
					System.out.println((idx[0]++) + ". " + location);
				});
				n = input.getStringInput("\n[0 to Exit Program]\n>> ");
				
				Integer i = Integer.parseInt(n);
				if(i < -1 || i >= idx[0]) {
					input.getStringInput("Input not valid ! Press [ENTER] to continue . . .");
					cls();
					continue;
				}
				cls();
				if(i == 0) {
					System.out.println("Program has ended, Goodbye !");
					return;
				}
				systems(management,i-1);
				
			}
		}
		
	}
	
	public void systems(Manager<GymProgram> management,Integer idx) {
		String n;
		GymProgram system = management.getList().get(idx);
		while(true) {
			n = input.getStringInput("===GYM MANAGEMENT SYSTEM [" + system.getLocation() +"]===\n1. Manage Location\n2. Manage Member\n3. Manage Package\n4. Manage Product\n5. System Guide (?)\n6. Exit Program\n>>");
			switch(n) {
			case "1":
				cls();
				CRUD(system);
				break;
			case "2":
				cls();
				CRUD(system.getMemberManager());
				break;
			case "3":
				cls();
				CRUD(system.getPackagesManager());
				break;
			case "4":
				cls();
				CRUD(system.getProductManager());
				break;
			case "5":
				cls();
				input.getStringInput("This management system is a simple program that can do simple CRUD (Create, Read, Update, and Delete) functions. To do such functions, simply enter the number on the menu and then you will be given more options to do the CRUD functions.\n\nPress [ENTER] to go back to the menu . . .");
				cls();
				break;
			case "6":
				cls();
				System.out.println("Succesfully exited the program.");
				return;
			default:
				input.getStringInput("You must enter the proper inputs ! Press [ENTER] to continue ...");
				cls();
			}
		}
	}
	//TODO: Benerin bagian ini, must be flexible so objects like member, products, etc can fit in this menu just fine
	public <T> void CRUD(T item) {
		String n;
		while(true) {
			n = input.getStringInput("Options:\n1. Add\n2. Display\n3. Update\n4. Search\n5. Delete\n6. Back to Main Menu\n>> ");
			switch(n) {
			case "1" :
				
				break;
			case "2" :
				break;
			case "3" :
				break;
			case "4" :
				break;
			case "5" :
				break;
			case "6" :
				break;
			default:
				input.getStringInput("You must enter the proper inputs ! Press [ENTER] to continue ...");
				cls();
			}
		}
	}
	
	public void addMember(GymProgram system) {
		String name,age,tier;
		
		System.out.print("Enter client name : ");
		name = scan.nextLine();
		
		System.out.print("Enter client's current age : ");
		age = scan.nextLine();
		
		System.out.print("Which tier would the client subscribe to ?\n1. Gold\n2. Base\n>> ");
		tier = scan.nextLine();
		
		if(tier == "1") {
			system.getMemberManager().add(new GoldMember(name,Integer.parseInt(age)));
		}
		else if(tier == "2") {
			system.getMemberManager().add(new Member(name,Integer.parseInt(age)));
		}
		
		System.out.println("Member added Succesfully ! Press [ENTER] to Continue . . .");
		scan.nextLine();
		cls();
	}
	public static void main(String[] args) {
		new Main();
	}
	public void cls() {
		for(int i = 0;i < 50;i++) System.out.println();
	}
}
