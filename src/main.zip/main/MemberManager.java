package main;
import java.util.*;
public class MemberManager implements Manager<Member>{
	private ArrayList<Member> membersList= new ArrayList<Member>();
	private InputHandler input= new InputHandler();
	@Override
	public void add(Member mem) {
		if(mem == null) throw new IllegalArgumentException("Member cannot be null");
		membersList.add(mem);
	}
	
	public void addMember() {
		
	}

	@Override
	public void sort(Comparator<Member> comparator) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("List of members : ");
		System.out.println("______________________________________________________");
		System.out.printf("| %-10s | %-15s | %-5s | %-15s |","Tier","Name","Age","Member Since");
		System.out.println("______________________________________________________");
		membersList.forEach(n ->System.out.printf("| %-10s | %-15s | %-5s | %-15s |\n",n.getTier(),n.getName(),String.valueOf(n.getAge()),n.getfirstSignUpDate()));
		System.out.println("______________________________________________________");
	}

	@Override
	public void delete(Member item) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ArrayList<Member> getList() {
		// TODO Auto-generated method stub
		return new ArrayList<Member>(membersList);
	}

	@Override
	public Integer search(ArrayList<Member> arr, Member item) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	

}
