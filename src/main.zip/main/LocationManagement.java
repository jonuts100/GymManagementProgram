package main;
import java.util.*;
public class LocationManagement implements Manager<GymProgram>{
	private ArrayList<GymProgram> locationList = new ArrayList<GymProgram>();


	@Override
	public void delete(GymProgram item) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sort(Comparator<GymProgram> comparator) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void add(GymProgram item) {
		// TODO Auto-generated method stub
		if(item == null) throw new IllegalArgumentException("Location cannot be null");
		locationList.add(item);
	}


	@Override
	public ArrayList<GymProgram> getList() {
		// TODO Auto-generated method stub
		return new ArrayList<GymProgram>(locationList);
	}

	@Override
	public Integer search(ArrayList<GymProgram> arr, GymProgram item) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
