package main;
import java.util.*;

public interface Manager<T> {
	void add(T item);
	void delete(T item);
	void sort(Comparator<T> comparator);
	void display();
	ArrayList<T> getList();
	Integer search(ArrayList<T> arr,T item);
}
