package main;
import java.util.*;
public class PackagesManager implements Manager<Packages>{
	private ArrayList<Packages> packagesList= new ArrayList<Packages>();

	public void addPackage(Packages pack) {
		if(pack == null) throw new IllegalArgumentException("Package cannot be null");
		packagesList.add(pack);
	}
	@Override
	public ArrayList<Packages> getList() {
		return new ArrayList<Packages>(packagesList);
	}

	@Override
	public void add(Packages item) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Packages item) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sort(Comparator<Packages> comparator) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public Integer search(ArrayList<Packages> arr, Packages item) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
