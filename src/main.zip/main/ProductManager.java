package main;
import java.util.*;
public class ProductManager implements Manager<Product>{
	private ArrayList<Product> productList= new ArrayList<Product>();
	@Override
	public void add(Product prod) {
		if(prod == null) throw new IllegalArgumentException("Product cannot be null");
		productList.add(prod);
	}
	@Override
	public ArrayList<Product> getList() {
		return new ArrayList<Product>(productList);
	}

	@Override
	public void delete(Product item) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sort(Comparator<Product> comparator) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		
	}
	public Integer search(ArrayList<Product> arr, Product item) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
