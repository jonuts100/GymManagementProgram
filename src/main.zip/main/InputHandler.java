package main;
import java.util.*;
public class InputHandler {
	Scanner scan = new Scanner(System.in);
	
	public String getStringInput(String text) {
		System.out.print(text);
		return scan.nextLine();
	}
	
	public Member addMember() {
		String name,age,tier;
		
		name = getStringInput("Enter client name : ");
		
		age = getStringInput("Enter client's current age : ");
		do {
			tier = getStringInput("Which tier would the client subscribe to ?\n1. Gold\n2. Base\n>> ");
			getStringInput("Input might be incorrect !\n");
		}while(!tier.equals("1") && !tier.equals("2"));
		
		if(tier == "1") {
			return new GoldMember(name,Integer.parseInt(age));
		}
		return new Member(name,Integer.parseInt(age));
	}

}
