package main;

public class GymProgram {
	private String location;
	private MemberManager memberManager;
	private ProductManager productManager;
	private PackagesManager packagesManager;
	
	public GymProgram(String location) {
		// TODO Auto-generated constructor stub
		memberManager = new MemberManager();
		productManager = new ProductManager();
		packagesManager = new PackagesManager();
		setLocation(location);
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public MemberManager getMemberManager() {
		return memberManager;
	}
	public ProductManager getProductManager() {
		return productManager;
	}
	public PackagesManager getPackagesManager() {
		return packagesManager;
	}
	@Override
	public String toString() {
		return location;
	}
	
}
