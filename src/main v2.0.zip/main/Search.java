package main;
import java.util.*;
public class Search {

	public Search() {
		// TODO Auto-generated constructor stub
	}
	
	public <T> T search(ArrayList<T> array, T itemName) {
		for(T item : array) {
			if(item == itemName)
		}
		return null;
		
	}

}
