package main;
import java.util.*;
public class Remove {
	
	public Remove() {
		// TODO Auto-generated constructor stub
	}
	
	public <T> void delete(ArrayList<T> array,T item) {
		
	}

}
